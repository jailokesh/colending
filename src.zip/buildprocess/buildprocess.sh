#! /bin/sh
PATH=/home/app/.nvm/versions/node/v10.16.0/bin:/usr/local/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/usr/tools/apache-ant-1.10.1/bin:/home/app/.local/bin:/home/app/bin:/softwares/gradle-2.2.1/bin:/softwares/node-v0.10.33-linux-x64/bin:/softwares/apache-maven-3.2.3/bin:/usr/jdk1.8.0_111/bin:/softwares/android/adt-bundle-linux-x86_64-20140702/sdk:/softwares/android/adt-bundle-linux-x86_64-20140702/sdk/tools/:/softwares/android/adt-bundle-linux-x86_64-20140702/sdk/platform-tools:/lib

echo $PATH

/home/app/.nvm/versions/node/v10.16.0/bin/npm i

/home/app/.nvm/versions/node/v10.16.0/bin/ng build --prod

cd dist/
zip -r CoLenWebNgSrc.zip CoLenWebNgSrc
