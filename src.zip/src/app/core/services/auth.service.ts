import { Injectable } from '@angular/core';
import { of, Observable, } from 'rxjs';
import { User } from '../../core/models/user.model';
import { ApiService } from './api.service'
import { tap, map, finalize, catchError, } from 'rxjs/operators';
import { Router } from '@angular/router';

export class ILoginContext {
  userId: string;
  Password: string;
  token: string;
}

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  token: string;
  isLoading: false;
  error: false
  constructor(
    private apiService: ApiService,
    private router: Router,
  ) { }

  login(loginContext: ILoginContext): Observable<any> {
    return this.apiService.post('/auth/authenticate', 'users', {
      "userId": loginContext.userId,
      "password": loginContext.Password
    })
  };

  logout(): Observable<boolean> {
    sessionStorage.clear();
    return of(false);
  }

  getToken() {
    return sessionStorage.getItem('token');
  }

  getName() {
    return sessionStorage.getItem('user');
  }

  getRole() {
    return sessionStorage.getItem('role'); 
  }

}
