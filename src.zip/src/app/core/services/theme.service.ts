import { Injectable } from '@angular/core';
import { BehaviorSubject, Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})

export class ThemeService {

  lightTheme = {};
  private dataSource = new Subject();
  currentData = this.dataSource.asObservable();

  toggleLight(color) {
    this.lightTheme = {
      'background-color': '#f0f1f3',
      'text-color': '#3c4858',
      'text-color-primary': '#FFF',
      'theme-color': color
    };
    this.setTheme(this.lightTheme);
    this.dataSource.next(this.lightTheme)
  }

  setTheme(theme: {}) {
    Object.keys(theme).forEach(k => {
      document.documentElement.style.setProperty(`--${k}`, theme[k])
    });
  }

}
