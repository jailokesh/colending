import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router'; 
import { AuthLayoutComponent } from './layouts/auth-layout/auth-layout.component';
import { ContentLayoutComponent } from './layouts/content-layout/content-layout.component'; 
import { CONTENT_ROUTES } from '@app/shared'; 
import { NoAuthGuard, AuthGuard } from '@app/core';

const routes: Routes = [
  {
    path: '',
    redirectTo: '/auth/login',
    pathMatch: 'full'
  },
  {
    path: '',
    component: ContentLayoutComponent,
    canActivate: [AuthGuard],
     // Should be replaced with actual auth guard
    data: {
      roles: ["SFE"]
    },
    children: CONTENT_ROUTES
  },
  {
    path: 'OPS',
    component: AuthLayoutComponent, 
    canActivate: [AuthGuard],
     // Should be replaced with actual auth guard
    data: {
      roles: ["OPS"]
    },
    loadChildren: () => import('./modules/ops/ops.module').then(m => m.OpsModule)
  },
  {
    path: 'auth',
    component: AuthLayoutComponent,
    loadChildren: () => import('./modules/auth/auth.module').then(m => m.AuthModule)
  },

  // Fallback when no prior routes is matched
  { path: '**', redirectTo: '/auth/login', pathMatch: 'full' }
]; 

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
