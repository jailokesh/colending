import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { keyvalueWithOutSort } from './keyvalueWithOutSort.pipe';

@NgModule({
  declarations: [keyvalueWithOutSort],
  imports: [
    CommonModule
  ],
  exports: [keyvalueWithOutSort]
})
export class PipeModule { }
