import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ops',
  templateUrl: './ops.component.html',
  styleUrls: ['./ops.component.scss']
})
export class OpsComponent implements OnInit {

  SNO1 =''
  SNO2 =''
  SNO3 =''
  SNO4 =''
  SNO5 =''
  constructor() { }

  ngOnInit() {
  }

}
