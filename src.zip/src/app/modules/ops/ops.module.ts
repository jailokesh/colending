import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { OpsComponent } from './pages/ops/ops.component';
import { OpsRoutingModule } from './ops-routing.module';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [OpsComponent],
  imports: [
    CommonModule,
    OpsRoutingModule,
    FormsModule
  ]
})
export class OpsModule { }
