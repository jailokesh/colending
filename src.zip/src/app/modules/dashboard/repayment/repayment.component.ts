import { Component, OnInit, ɵConsole } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { AuthService, ApiService } from '@app/core';
import * as moment from 'moment';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { catchError, finalize, tap } from 'rxjs/operators';
import { of } from 'rxjs';

@Component({
  selector: 'app-repayment',
  templateUrl: './repayment.component.html',
  styleUrls: ['./repayment.component.scss']
})
export class RepaymentComponent implements OnInit {
  isLoading: boolean;
  afterLoad: boolean;
  tableValue: any;
  inputReadonly = true;
  namChange = {
    "nbfcWithCrossell": "NBFC With Cross Sell",
    "colenCrosssell": "Chola Schedule Only Cross Sell",
    "colenBank": "Colen Bank",
    "colenNbfc": "Colen NBFC",
    "colenCustomer": "Colen Customer"
  }
  listItems: any;
  colen = {};
  repayForm: FormGroup;
  submitted = false;
  minDate: any;
  p: any;
  error: any;
  EMIamount = [];

  constructor(private formBuilder: FormBuilder, private apiservice: ApiService, private ngxLoader: NgxUiLoaderService) {

    this.repayForm = this.formBuilder.group({
      principal: [100000, [Validators.required, Validators.min(10000), Validators.max(100000000), Validators.pattern(/^[0-9]+$/)]],
      tenure: [10, [Validators.required, Validators.min(5), Validators.max(150)]],
      cycleDate: [(new Date()), Validators.required],
      actualPaymentDate: [(new Date()), Validators.required],
      bankRate: [10, [Validators.required, Validators.max(100)]],
      customerRate: [10, [Validators.required, Validators.max(100)]],
      bankPercentage: [80, [Validators.required, Validators.max(100)]],
      nbfcPercentage: [20, [Validators.required, Validators.max(100)]],
      crossSellAmount: [1000, Validators.required],
      preEMIDays: [360, [Validators.required]],
      roundType: [1, [Validators.required]],
      fixedDigits: [0, [Validators.required, Validators.min(0), Validators.max(5)]],
      repayCode: ['CH_RPY_BRP_PREEMI', [Validators.required]],
      moratoriumDays: [0, [Validators.required]]
    }, { validator: this.myValidator });
    this.repayForm.get('actualPaymentDate').valueChanges.subscribe(value => {
      this.minDate = new Date(value);
      this.repayForm.controls["cycleDate"].setValue('');
    });

  }

  ngOnInit() {
    this.repayementDetails();
  }

  get f() { return this.repayForm.controls; }

  repayementDetails() {
    this.error = undefined;
    this.submitted = true;
    if (this.repayForm.invalid) {
      return;
    }
    this.listItems = [];
    this.colen['display'] = 1;
    this.colen['formatFlag'] = 'Chart';
    this.repayForm.value.cycleDate = moment(this.repayForm.value.cycleDate, 'DD/MM/YYYY').format("DD/MM/YYYY");
    this.repayForm.value.actualPaymentDate = moment(this.repayForm.value.actualPaymentDate, 'DD/MM/YYYY').format("DD/MM/YYYY");
    // delete this.repayForm.value.cycleDate;
    // delete this.repayForm.value.actualPaymentDate;
    this.repayForm.value.fixedDigits = this.repayForm.value.roundType == 0 ? this.repayForm.value.fixedDigits : 0;
    let obj = { ...this.colen, ...this.repayForm.value };
    // this.ngxLoader.start();
    this.apiservice.post('/repayment', 'repayment', obj).pipe(
      tap(res => {
        if (res.repaymentSchedule.status == 'success') {
          this.afterLoad = true;
          this.error = undefined;
          this.tableValue = res;
          console.log(this.tableValue);
          this.listItems = Object.keys(this.tableValue.repaymentSchedule).filter(a => a != 'message' && a != 'status' && typeof(this.tableValue.repaymentSchedule[a]) == 'object');  
          this.listItems.filter(a => {
            console.log(typeof(this.tableValue.repaymentSchedule[a]))
          })
          this.listItems.map(a => { 
            if (typeof (this.tableValue.repaymentSchedule[a]) == 'object') {
              this.tableValue.repaymentSchedule[a].data = this.tableValue.repaymentSchedule[a].data.map((b, i) => {
                b['ind'] = i;
                return b;
              })
            }
          });
          setTimeout(() => {
            this.error = undefined;
          }, 3000);
        }
      }),
      finalize(() => this.isLoading = false),
      catchError(error => of(this.error = this.callMsg()))
    ).subscribe();
  }

  callMsg() {
    setTimeout(() => {
      this.error = undefined;
    }, 3000);
    return "Invalid Unknown Error !"
  }

  myValidator(group: FormGroup) {
    let sum = group.get(['bankPercentage']).value + group.get(['nbfcPercentage']).value;
    if (sum > 100) {
      return { notValid: true };
    } else if (sum == 0) {
      return null;
    } else if (sum < 100) {
      return { notValid: true };
    }
  }

}
