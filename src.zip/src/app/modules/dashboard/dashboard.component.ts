import { Component, OnInit } from '@angular/core';
import { Router, NavigationExtras, ActivatedRoute } from '@angular/router';
import { AuthService, ApiService } from '@app/core';
import { tap, map, finalize, catchError, } from 'rxjs/operators';
import { of, throwError, from } from 'rxjs';
import { DataTrasferService } from 'app/shared/services'; 

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
  error: string;
  isLoading: boolean;
  countDetails: {};
  parameter: {};
  dashboardLead: [];
  leadDetails: [];
  tabValue = 'pending';
  p: any;

  constructor(private router: Router, private apiService: ApiService, private serviceDataTransfer: DataTrasferService, ) {
    this.onload('pending');
    this.serviceDataTransfer.currentData.subscribe(res => { 
      if (res == 'changePending') { 
        this.onload('pending');
        this.tabValue = 'pending';
      }
    })
  }

  ngOnInit() {
  }

  onload(status) { 
    this.apiService.get('/getAppStatus', 'underwriting', { type: 'getAppStatus' }).pipe(
      tap(res => {
        this.countDetails = res;
        this.serviceDataTransfer.changeData(this.countDetails);
      }),
      finalize(() => this.isLoading = false),
      catchError(error => of(this.error = error))
    ).subscribe();
    this.parameter = {
      bankname: 'KVB',
      type: 'coLenDashboard',
      status: status
    }
    this.apiService.get('/getColendingDashboardLeads', 'underwriting', this.parameter).pipe(
      tap(res => {
        this.dashboardLead = res;
      }),
      finalize(() => this.isLoading = false),
      catchError(error => of(this.error = error))
    ).subscribe();
  }

  tabChange(val) {
    this.tabValue = val;
    this.onload(this.tabValue);
  }

  golead(LeadID, approveStauts) {
    let navigationExtras: NavigationExtras = {
      queryParams: {
        LeadID,
        approveStauts
      }
    };
    this.router.navigate(['/home'], navigationExtras)
  }

  changeIcon(val) {
    if (val.toLowerCase() == 'pending') {
      return 'fa-hourglass-half'
    } else if (val.toLowerCase() == 'accepted') {
      return 'fa-check'
    } else if (val.toLowerCase() == 'overall') {
      return 'fa-check'
    } else if (val.toLowerCase() == 'rejected') {
      return 'fa-close'
    }
  }

  changeDateFormat(date) {
    return new Date(date); 
  }

}
