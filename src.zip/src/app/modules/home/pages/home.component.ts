import { Component, OnInit } from '@angular/core';
import { of, Observable } from 'rxjs';
import { tap, finalize, catchError } from 'rxjs/operators';
import { Router, ActivatedRoute } from '@angular/router';
import { ApiService } from '@app/core';
import { NgxSmartModalService } from 'ngx-smart-modal'
import { DepFlags } from '@angular/compiler/src/core';
import { DataTrasferService } from 'app/shared/services'; 

@Component({
    selector: 'app-home',
    templateUrl: './home.component.html',
    styleUrls: ['./home.component.scss']
})
export class HomeComponent {

    isLoading = false;
    error = null;
    values: any;
    leadDetails: {};
    parameter: {};
    afterLoad = false;
    leadID: string;
    bankName: string;
    status: string;
    showReject = true;
    parameterValue: string;
    reasonForReject: string;
    commonStyle: any;
    selectedTab: any;
    selectedTabList = {};
    tabNameListSelected: any;
    temp = [];
    toggleValue = false;
    iterateValueShow: any;
    icons = { 'Name': 'fa-user', 'Loan Amount': 'fa-inr', 'Interest Rate': 'fa-percent', 'Tenure': 'fa-calendar-check-o', 'Credit Score': 'fa-star-half-full' };
    tabNames = ['profileDetails', 'assetFunding', 'DOCUMENTS'];
    documents: any;
    iconShowplusMinus = {};
    firstValue = [] as any;
    secondValue = [] as any;
    showCls = false;
    imgShow = false;

    constructor(
        private apiService: ApiService,
        private router: Router,
        public modalService: NgxSmartModalService,
        private route: ActivatedRoute,
        private serviceDataTransfer: DataTrasferService 
    ) {
        this.selectedTab = 'profileDetails';
        this.serviceDataTransfer.currentData.subscribe(res => { 
            if (res == 'yes') {
                this.acknowledgement(this.parameterValue, this.reasonForReject);
            }
        });
        this.route.queryParams.subscribe(params => {
            this.leadID = params.LeadID;
            this.status = params.approveStauts;
            this.leadDetails = {
                bankname: 'KVB',
                type: 'coLenLead',
                leadid: params.LeadID
            }
            this.apiService.get('/getColendingLeads', 'underwriting', this.leadDetails).pipe(
                tap(res => {
                    this.values = res;
                    this.documents = res[0].documents; 
                    this.afterLoad = true;
                    this.tabChange('profileDetails');
                }),
                finalize(() => this.isLoading = false),
                catchError(error => of(this.error = error))
            ).subscribe();
        });
    }

    checkType(type) {
        if (typeof (type) == 'string') {
            return type.replace(
                /\w\S*/g,
                function (txt) {
                    return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();
                }
            );
        } else {
            return type;
        }
    }

    callIcon(icon) {
        return this.icons[icon];
    }

    tabChange(tabName) {
        this.temp = [];
        this.selectedTab = tabName;
        this.tabNameListSelected = this.values[0][tabName];
        if (this.tabNameListSelected) {
            Object.keys(this.tabNameListSelected).map((a, i) => {
                if (typeof (this.tabNameListSelected[a]) == 'object') {
                    this.tabNameListSelected[a]['index'] = i;
                    this.temp.push(this.tabNameListSelected[a]);
                }
            });
            this.tabChangeList(this.temp[0].labelName, this.temp[0].index);
        } else {
            this.iterateValueShow = {};
        }
    }

    tabChangeList(tabListName, index) {
        this.selectedTabList = {};
        this.selectedTabList[tabListName + index] = true;
        Object.keys(this.tabNameListSelected).map((a, i) => {
            if (this.tabNameListSelected[a].labelName == tabListName) {
                this.iterateValueShow = this.tabNameListSelected[a];
                this.funcall(this.iterateValueShow);
            }
        })
    }

    plusOrminus(index) { 
    }

    funcall(val) {
        this.firstValue = [];
        this.secondValue = [];
        Object.values(val).map((typeVal: any) => {
            if (typeof (typeVal.value) != undefined) {
                if (typeof (typeVal) == 'object') {
                    this.firstValue.push(typeVal);
                    this.showCls = false;
                    if (typeVal.value || typeVal.value == '') {
                        this.showCls = true;
                        this.secondValue.push(typeVal);
                    }
                }
            }
        })
    }

    acknowledgement(status, rejectRemarks) { 
        this.parameter = {
            "ackType": 'SANCTIONED',
            "ackStatus": status,
            "partnerID": this.leadID,
            "bankName": 'KVB',
            "remarks": rejectRemarks != undefined ? rejectRemarks : 'no'
        }
        this.apiService.put('/coLendingLeadStatusUpdate', 'underwriting', this.parameter).pipe(
            tap(res => {
                this.openPopUp({
                    title: 'Alert',
                    msg: res.message
                });
                this.status = status;
                this.showReject = true;
                this.router.navigate(['/dashboard']);
                rejectRemarks = '';
            }),
            finalize(() => this.isLoading = false),
            catchError(error => of(this.error = error))
        ).subscribe();
    }

    confirm(status, paraValue) {
        this.openPopUp({
            title: 'Confirmation',
            msg: 'Are you sure to ' + status + ' the lead',
            confirmation: 'need',
            purpose: 'acknowledgment'
        });
        this.parameterValue = paraValue;
    }

    openPopUp(obj) {
        this.modalService.setModalData(obj, 'infoModal', true);
        this.modalService.getModal('infoModal').open();
    }

    submit(status, rejectVal) {
        if (rejectVal) {
            this.confirm(status, 'REJECTED');
            this.reasonForReject = rejectVal;
        }
        else {
            this.openPopUp({
                title: 'Validation error',
                msg: 'Please enter reason for rejection'
            });
        }
    }

    getKYCimage(imageURL) {
        this.imgShow = true;
        let temp = imageURL.apiUrl; 
        return temp;
        // this.apiService.get('/fetchKycDocs', 'underwriting', imageURL.imageUrl).pipe(
        //     tap((responseType: Response) => {
        //         console.log(responseType);
        //         this.img = responseType;
        //     }),
        //     finalize(() => this.isLoading = false),
        //     catchError(error => of(this.error = error))
        // ).subscribe(); 
    }

    getpopup(val){  
        this.openPopUp({
            title: 'Image',
            imageUrl: val.imageUrl
        });
    }

}
