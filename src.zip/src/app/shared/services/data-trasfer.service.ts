import { Injectable } from '@angular/core';
import { BehaviorSubject, Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DataTrasferService {

  private dataSource = new Subject();
  currentData = this.dataSource.asObservable();
  
  constructor() { }

  changeData(data:any) {
    this.dataSource.next(data)
  }
}
