import { Component, OnInit } from '@angular/core';
import { environment } from '@env/environment';
import { AuthService } from '../../core/services/auth.service';
import { Router } from '@angular/router';
import { NgxSmartModalService } from 'ngx-smart-modal';
import { DataTrasferService } from 'app/shared/services';
import { ThemeService } from '../../core/services';

@Component({
  selector: 'app-nav',
  templateUrl: './nav.component.html',
  styleUrls: ['./nav.component.scss']
})
export class NavComponent implements OnInit {

  version = environment.version;
  loggedUserName: String;
  pendingCount: any;
  parameter: any;
  error: string;
  isLoading: boolean;
  themeBank: any;
  navItems = [
    { link: '/dashboard/home', title: 'Home' },
    { link: '/about', title: 'About' },
    { link: '/contact', title: 'Contact' }
  ];

  colors = [
    '#003f88',
    '#00A85A',
    '#e91e63',
    '#F36523',
    '#2ca8ff',
    '#ff9800',
    '#9368e9',
    '#0091ea',
    '#3e2723',
    '#00bfa5',
    '#afb42b',
    '#546e7a'
  ];

  toggleValue = false;

  constructor(
    private auth: AuthService,
    private router: Router,
    public modalService: NgxSmartModalService,
    private serviceDataTransfer: DataTrasferService,
    private overallColor: ThemeService
  ) {
    this.serviceDataTransfer.currentData.subscribe(res => {

      if (res) {
        sessionStorage.setItem('countpending', res['pending']);
        this.pendingCount = sessionStorage.getItem('countpending');
      } else {
        this.pendingCount = 0;
      }

      if (res == 'ok') {
        this.auth.logout();
        this.router.navigate(['/auth/login']);
        this.openPopUp({
          title: 'Success!',
          msg: 'You have been logged out successfully'
        });
      }
      else {
        this.modalService.getModal('infoModal').close();
      }
    });

    if (sessionStorage.getItem('color')) {
      this.overallColor.toggleLight(sessionStorage.getItem('color'));
      this.themeBank = sessionStorage.getItem('themeBasedImage');
    } else {
      this.overallColor.toggleLight('#003f88');
    }

    if (sessionStorage.getItem('countpending')) {
      this.pendingCount = sessionStorage.getItem('countpending');
    }

  }

  ngOnInit() {
    if (this.auth.getToken()) {
      this.loggedUserName = this.auth.getName()
    }
  }

  logOut() {
    this.openPopUp({
      title: 'Confirmation',
      msg: 'Are you sure want to logout ?',
      confirmation: 'need',
      purpose: 'LogOut'
    });
  }

  openPopUp(obj) {
    this.modalService.setModalData(obj, 'infoModal', true);
    this.modalService.getModal('infoModal').open()
  }

  notification() {
    if (this.router['url'] == '/dashboard') {
      this.serviceDataTransfer.changeData('changePending');
    } else {
      this.router.navigate(['/dashboard']);
    }

  }

  toggle() {
    this.toggleValue = this.toggleValue == false ? true : false;
  }

  changeColor(color) {
    sessionStorage.setItem('color', color);
    this.overallColor.toggleLight(color);
  }

}
