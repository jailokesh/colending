import { Component, OnInit } from '@angular/core';
import { ThemeService } from '../../core/services';

@Component({
  selector: 'app-auth-layout',
  templateUrl: './auth-layout.component.html',
  styleUrls: ['./auth-layout.component.scss']
})
export class AuthLayoutComponent implements OnInit {
  
  constructor(private overallColor: ThemeService) {
    this.overallColor.toggleLight('#003f88');
  }

  ngOnInit() {
    
  }

}
