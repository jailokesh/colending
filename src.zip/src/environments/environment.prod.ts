export const environment = {
  production: true,
  serverUrl : "mastersapi",
  serverUrlSet : {
    masters : "mastersapi",
    users : "usermanagementapi",
    underwriting : "underwritingapi"
  },
  envName : 'Production',
  version : 'v0.1'
};
